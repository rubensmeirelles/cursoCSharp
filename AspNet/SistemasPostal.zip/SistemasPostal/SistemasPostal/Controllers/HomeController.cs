﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemasPostal.Context;
using SistemasPostal.Models;
using System.Diagnostics;

namespace SistemasPostal.Controllers
{
    public class HomeController : Controller
    {
        private readonly SistemaContext _context;

        public HomeController(SistemaContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

       
        public IActionResult Sistemas()
        {
            var sistemas = _context.Sistemas.ToList();
            return View(sistemas);
        }

        public IActionResult Cadastrar()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}