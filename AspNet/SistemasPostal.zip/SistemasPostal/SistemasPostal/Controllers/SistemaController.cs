﻿using Microsoft.AspNetCore.Mvc;
using SistemasPostal.Context;
using SistemasPostal.Models;

namespace SistemasPostal.Controllers
{
    public class SistemaController : Controller
    {
        private readonly SistemaContext _context;

        public SistemaController(SistemaContext context) 
        { 
            _context = context; 
        }

        public IActionResult Sistemas()
        {
            var sistemas = _context.Sistemas.ToList();
            return View(sistemas);
        }
    }
}
