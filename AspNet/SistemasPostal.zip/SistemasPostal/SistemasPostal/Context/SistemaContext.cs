﻿using Microsoft.EntityFrameworkCore;
using SistemasPostal.Models;

namespace SistemasPostal.Context
{
    public class SistemaContext : DbContext
    {
        public SistemaContext(DbContextOptions<SistemaContext> options) : base(options)
        {

        }

        public DbSet<Sistema> Sistemas { get; set; }

    }
}
