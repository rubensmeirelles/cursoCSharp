﻿namespace SistemasPostal.Models
{
    public class Sistema
    {
        public int Id { get; set; }
        public string NomeDoSistema { get; set; }
        public string Gerencia { get; set; }
        public string UrlProducao { get; set; }
        public string UrlHomologacao { get; set; }
        public string Usuario { get; set; }
        public string Senha { get; set; }
        public string Documentacao { get; set; }
    }
}
